
package kuis;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;



public class FXMLDocumentController implements Initializable {
    
   
    
    
   @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private DatePicker tanggal;
    
    @FXML
    private TextField merek;
    
    @FXML
    private TextField warna;

    @FXML
    private TextField harga;

    @FXML
    private Button simpan;


    @FXML
    void initialize() {
        assert tanggal != null : "fx:id=\"tanggal\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert harga != null : "fx:id=\"harga\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert simpan != null : "fx:id=\"simpan\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert merek != null : "fx:id=\"merek\" was not injected: check your FXML file 'FXMLDocument.fxml'.";
        assert warna != null : "fx:id=\"warna\" was not injected: check your FXML file 'FXMLDocument.fxml'.";

    }
    
    
   
    @FXML
    private void handleButtonAction(ActionEvent event) throws SQLException {
       
        bajuDataModel datamodel = new bajuDataModel();
        
       baju baju = new baju();
       baju.setTanggal_pembelian(tanggal.getValue().toString());
       baju.setMerek(merek.getText());
       baju.setHarga(Integer.parseInt(harga.getText()));
       baju.setWarna(warna.getText());
       
       datamodel.addVGAcard(baju);
        
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       ArrayList <String> list = new ArrayList<String>();
        list.add("BAJU ORAQLE");
        list.add("BAJU GUCCI");
        list.add("BAJU 3SECOND");
        list.add("BAJU SUPREME");
        ObservableList items = FXCollections.observableArrayList(list);
        
        
        
    }    
}
