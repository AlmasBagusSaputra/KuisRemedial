/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kuis;


import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.sql.SQLException;
import kuis.db.DBHelper;

public class bajuDataModel {
    
    private final  Connection conn;

    public bajuDataModel() throws SQLException {
        this.conn =DBHelper.getConnection();
    }
    
    public void addVGAcard(baju baju){
    String insertbaju = "INSERT INTO baju ( `tanggal_pembelian`, `merek`, `harga`, `warna`)"
            + "VALUES ('"
            +baju.getTanggal_pembelian()+"','"
            +baju.getMerek()+"','"
            +baju.getHarga()+"','"
            +baju.getWarna()+"')";
    try {
    
    PreparedStatement card = (PreparedStatement) conn.prepareStatement(insertbaju);
//    
////    card.setString(1, baju.getTanggal_pembelian());
////    card.setString(2, baju.getMerek());
////    card.setString(3, baju.getWarna());
////    card.setInt(4, baju.getHarga());
//    
    card.execute();
    }
    catch(Exception e){
        System.out.println("eror "+e);
    }
    }
    
}
